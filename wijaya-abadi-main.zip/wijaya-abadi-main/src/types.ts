import type { CatalogAnimation } from './catalogAnimation';

export interface MotorSpec {
  id?: string;
  name: string;
}

export interface Motor {
  id: string;
  name: string;
  category: string;
  price: string;
  numericPrice?: number;
  image: string;
  images?: string[];
  specs: string[];
  description: string;
  created_at?: string;
  updated_at?: string;
  interest_count?: number;
  is_bestseller?: boolean;
}

export interface FIFPriceListModel {
  price: number;
  options: Record<string, number[]>;
}

export interface FIFPriceList {
  source: string;
  updatedAt?: string;
  tenors: number[];
  models: Record<string, FIFPriceListModel>;
}

export type PromoTemplate = 'classic' | 'showcase' | 'compact';

export interface Promo {
  id: string;
  title: string;
  description: string;
  terms: string;
  badge?: string;
  discountValue?: string;
  images?: string[];
  promoAnimation?: CatalogAnimation;
  promoTemplate?: PromoTemplate;
  created_at?: string;
  isGlobal?: boolean;
  isLocal?: boolean;
  disabledHosts?: string[];
}

export interface Article {
  id: string;
  title: string;
  slug: string;
  category: string;
  excerpt: string;
  content: string;
  image?: string;
  images?: string[];
  animation?: CatalogAnimation;
  animationSpeed?: number;
  author: string;
  published: boolean;
  created_at?: string;
  updated_at?: string;
}

export interface Testimonial {
  id: string;
  name: string;
  motor: string;
  rating: number;
  comment: string;
  email?: string;
  phone?: string;
  approved?: boolean;
  date?: string;
  created_at?: string;
}

export interface ManifestoItem {
  id: string;
  number: string;
  title: string;
  description: string;
  created_at?: string;
}

export interface SeoLandingPage {
  id: string;
  subdomain: string;
  domainSuffix?: 'kreditmotorhonda.id' | 'kreditmotorhonda.tech' | 'solusikreditmotor.cloud';
  siteType?: 'pos' | 'sales-counter';
  parentSeoPageId?: string | null;
  posAdminUserIds?: string[];
  adminUserId: string;
  title: string;
  content: string;
  posts?: SeoLandingPost[];
  promos?: Promo[];
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  seoRobots: string;
  siteSettings?: Partial<SeoPostSiteSettings>;
  sslStatus?: 'pending' | 'provisioning' | 'active' | 'failed';
  sslError?: string;
  updated_at?: string;
}

export interface SalesCounterSite {
  id: string;
  siteType: 'pos' | 'sales-counter';
  parentSeoPageId?: string | null;
  subdomain: string;
  domainSuffix: 'kreditmotorhonda.id' | 'kreditmotorhonda.tech' | 'solusikreditmotor.cloud';
  name: string;
  phone: string;
  username: string;
  adminUserId: string;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  seoRobots?: string;
  sslStatus?: 'pending' | 'provisioning' | 'active' | 'failed';
  sslError?: string;
  updated_at?: string;
}

export interface SeoLandingPost {
  id: string;
  slug: string;
  title: string;
  content: string;
  authorUsername?: string;
  authorRole?: string;
  created_at?: string;
  updated_at?: string;
}

export interface SeoPostSiteSettings {
  name?: string;
  tagline?: string;
  phone?: string;
  address?: string;
  email?: string;
  workingHours?: string;
  logo?: string;
  heroImage?: string;
  heroImages?: string[];
  heroTitle?: string;
  heroMainTitle?: string;
  heroTitleHighlight?: string;
  heroSubtitle?: string;
  heroBadge?: string;
  heroCaption?: string;
  footerText?: string;
  websiteTemplate?: WebsiteTemplate;
  catalogAnimation?: CatalogAnimation;
  catalogAnimationSpeed?: number;
  customization?: WebsiteCustomization;
}

export type WebsiteTemplate = 'classic' | 'premium' | 'minimal' | 'luxury' | 'sport' | 'showroom' | 'signature' | 'urban' | 'mulia-cerah' | 'honda-wijaya' | 'wijaya-cool' | 'wijaya-meriah' | 'showcase-wijaya-2' | 'astra-honda-red-white' | 'honda-tokyo-racing-edition' | 'astra-honda-november-edition' | 'astra-honda-electric-flame-edition' | 'wijaya-enerjik';
export type HeroAlignment = 'left' | 'center' | 'right';
export type SiteFont = 'jakarta' | 'serif' | 'mono' | 'system' | 'outfit' | 'inter' | 'montserrat';
export type ThemeMode = 'light' | 'dark';
export type CardRadius = 'sharp' | 'soft' | 'round';
export type HeroAnimation = CatalogAnimation;
export type { CatalogAnimation } from './catalogAnimation';

export interface ThemeColorPalette {
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  backgroundColor?: string;
  panelColor?: string;
  cardColor?: string;
  elevatedColor?: string;
  borderColor?: string;
  textColor?: string;
  mutedColor?: string;
  font?: SiteFont;
  heroTextColor?: string;
  heroTitleHighlightColor?: string;
}

export interface WebsiteCustomization {
  primaryColor?: string;
  secondaryColor?: string;
  accentColor?: string;
  backgroundColor?: string;
  panelColor?: string;
  cardColor?: string;
  elevatedColor?: string;
  borderColor?: string;
  textColor?: string;
  mutedColor?: string;
  font?: SiteFont;
  heroAlignment?: HeroAlignment;
  cardRadius?: CardRadius;
  heroTextColor?: string;
  heroTextFont?: string;
  heroBadgeFontSize?: number;
  heroTitleFontSize?: number;
  heroHighlightFontSize?: number;
  heroHeadlineGap?: number;
  heroSubtitleFontSize?: number;
  heroCaptionFontSize?: number;
  heroTitleHighlightColor?: string;
  heroOverlayColor?: string;
  heroOverlayOpacity?: number;
  themeBackgroundImage?: string;
  themeBackgroundAnimation?: boolean;
  colorPalettes?: Partial<Record<ThemeMode, ThemeColorPalette>>;
  templatePaletteBackup?: Partial<Record<ThemeMode, ThemeColorPalette>>;
}

export interface DealerSettings {
  id: string;
  name: string;
  tagline: string;
  phone: string;
  address: string;
  email: string;
  workingHours: string;
  logo: string;
  heroImage: string;
  heroImages?: string[];
  heroTitle: string;
  heroMainTitle?: string;
  heroTitleHighlight?: string;
  heroSubtitle: string;
  heroBadge?: string;
  heroCaption?: string;
  heroAnimation?: HeroAnimation;
  heroAnimationSpeed?: number;
  footerText: string;
  socialLinks?: {
    youtube?: string;
    instagram?: string;
    facebook?: string;
    x?: string;
    linkedin?: string;
  };
  seoTitle?: string;
  seoDescription?: string;
  seoFocusKeyword?: string;
  seoKeywords?: string;
  seoCanonicalUrl?: string;
  seoRobots?: string;
  seoPages?: SeoLandingPage[];
  seoPostHost?: boolean;
  websiteTemplate?: WebsiteTemplate;
  catalogAnimation?: CatalogAnimation;
  catalogAnimationSpeed?: number;
  featuredMotorRotationInterval?: number;
  customization?: WebsiteCustomization;
  updated_at?: string;
}

export interface AdminSession {
  id: string;
  username: string;
  role: string;
  createdAt?: string;
  assignedSeoPageId?: string;
  assignedHost?: string;
}

export interface AdminUser {
  id: string;
  username: string;
  role: string;
  created_at?: string;
  updated_at?: string;
  assignedSeoPageId?: string | null;
  assignedHost?: string | null;
  assignedSeoPage?: {
    id: string;
    subdomain: string;
    title?: string;
  } | null;
  assignedSeoPages?: Array<{
    id: string;
    subdomain: string;
    title?: string;
  }>;
}

export interface AuditLog {
  id: string;
  actor: string;
  action: string;
  resource: string;
  details: string;
  created_at: string;
}

export interface LeadInterest {
  id: string;
  salesCounterSiteId?: string;
  host?: string;
  motor_id?: string;
  motor_name?: string;
  customer_name: string;
  phone: string;
  payment_method?: 'Cash' | 'Kredit';
  dp_estimate?: string;
  note?: string;
  source?: 'form' | 'whatsapp-click';
  status: 'Baru' | 'Dihubungi' | 'Selesai' | 'Ditolak';
  created_at: string;
}

export interface CreditCalculation {
  price: number;
  dpPercent: number;
  dpAmount: number;
  loanAmount: number;
  tenorMonths: number;
  interestRateAnnual: number;
  monthlyInstallment: number;
  totalPayment: number;
}
